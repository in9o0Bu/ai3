// 张诣航的AI助手 - 回答系统
document.addEventListener('DOMContentLoaded', function() {
    // 获取DOM元素
    const chatContainer = document.getElementById('chat-container');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const quickBtns = document.querySelectorAll('.quick-btn');

    // 预设回答映射
    const answerMap = {
        // 作品相关关键词
        '作品': '我最满意的作品就是这个网站，因为这是我一个新的尝试，也是我花了2个月学习与打磨的成果。（测试阶段回答可能有差错，请谅解！）',
        '满意': '我最满意的作品就是这个网站，因为这是我一个新的尝试，也是我花了2个月学习与打磨的成果。（测试阶段回答可能有差错，请谅解！）',
        '项目': '我最满意的作品就是这个网站，因为这是我一个新的尝试，也是我花了2个月学习与打磨的成果。（测试阶段回答可能有差错，请谅解！）',
        '网站': '我最满意的作品就是这个网站，因为这是我一个新的尝试，也是我花了2个月学习与打磨的成果。（测试阶段回答可能有差错，请谅解！）',
        
        // 离职相关关键词
        '离职': '上一份工作离职是因为工作性质属于天天出差，然后偏离了本职工作，每天都要求去各个工业园区做服务生，每次都是做与本职工作不相关的事情与自己职业规划不符。（测试阶段回答可能有差错，请谅解！）',
        '辞职': '上一份工作离职是因为工作性质属于天天出差，然后偏离了本职工作，每天都要求去各个工业园区做服务生，每次都是做与本职工作不相关的事情与自己职业规划不符。（测试阶段回答可能有差错，请谅解！）',
        '工作': '上一份工作离职是因为工作性质属于天天出差，然后偏离了本职工作，每天都要求去各个工业园区做服务生，每次都是做与本职工作不相关的事情与自己职业规划不符。（测试阶段回答可能有差错，请谅解！）',
        '出差': '上一份工作离职是因为工作性质属于天天出差，然后偏离了本职工作，每天都要求去各个工业园区做服务生，每次都是做与本职工作不相关的事情与自己职业规划不符。（测试阶段回答可能有差错，请谅解！）',
        
        // 东莞相关关键词
        '东莞': '想在沿海发展一下，学习一下。（测试阶段回答可能有差错，请谅解！）',
        '沿海': '想在沿海发展一下，学习一下。（测试阶段回答可能有差错，请谅解！）',
        '发展': '想在沿海发展一下，学习一下。（测试阶段回答可能有差错，请谅解！）',
        '学习': '想在沿海发展一下，学习一下。（测试阶段回答可能有差错，请谅解！）',
        
        // 退伍相关关键词
        '退伍': '部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）',
        '部队': '部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）',
        '军人': '部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）',
        '通讯营': '部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）',
        '受伤': '部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）'
    };

    // 添加用户消息到聊天
    function addUserMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user-message';
        messageDiv.innerHTML = `
            <div class="avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="message-content">
                <div class="message-header">
                    <strong>访客</strong>
                    <span class="time">${getCurrentTime()}</span>
                </div>
                <div class="message-text">${escapeHtml(text)}</div>
            </div>
        `;
        chatContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    // 添加AI消息到聊天
    function addAIMessage(text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message ai-message';
        messageDiv.innerHTML = `
            <div class="avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="message-header">
                    <strong>张诣航的AI助手</strong>
                    <span class="time">${getCurrentTime()}</span>
                </div>
                <div class="message-text">${escapeHtml(text)}</div>
            </div>
        `;
        chatContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    // 获取当前时间
    function getCurrentTime() {
        const now = new Date();
        return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    }

    // 滚动到底部
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // HTML转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // 分析问题并获取回答
    function getAnswer(question) {
        const lowerQuestion = question.toLowerCase();
        
        // 检查关键词匹配
        for (const [keyword, answer] of Object.entries(answerMap)) {
            if (lowerQuestion.includes(keyword.toLowerCase())) {
                return answer;
            }
        }
        
        // 没有匹配的关键词
        return '请联系本人获取详细解答。';
    }

    // 处理用户输入
    function handleUserInput() {
        const question = userInput.value.trim();
        
        if (!question) {
            return;
        }
        
        // 添加用户消息
        addUserMessage(question);
        
        // 清空输入框
        userInput.value = '';
        
        // 模拟AI思考时间
        setTimeout(() => {
            const answer = getAnswer(question);
            addAIMessage(answer);
        }, 500);
    }

    // 发送按钮点击事件
    sendBtn.addEventListener('click', handleUserInput);

    // 输入框回车事件
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleUserInput();
        }
    });

    // 快速提问按钮
    quickBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const question = this.getAttribute('data-question');
            userInput.value = question;
            handleUserInput();
        });
    });

    // 自动调整输入框高度
    userInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // 初始化输入框高度
    userInput.style.height = 'auto';
    userInput.style.height = (userInput.scrollHeight) + 'px';

    console.log('张诣航的AI助手已启动');
    console.log('支持的关键词：', Object.keys(answerMap));
});