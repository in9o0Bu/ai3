# 张诣航的AI助手

一个代表平面设计师张诣航回答常见问题的AI助手，可集成到个人网站中。

## 功能特性

- 🤖 **AI代表回答**：模拟张诣航回答访客问题
- 🔍 **关键词匹配**：根据问题关键词选择预设回答
- 🎯 **专业回答**：基于真实经历和观点的回答
- 📱 **响应式设计**：适配所有设备
- ⚡ **快速响应**：即时回答，无需等待

## 预设回答

### 1. 作品相关
**关键词**：作品、满意、项目、网站  
**回答**：我最满意的作品就是这个网站，因为这是我一个新的尝试，也是我花了2个月学习与打磨的成果。（测试阶段回答可能有差错，请谅解！）

### 2. 离职原因
**关键词**：离职、辞职、工作、出差  
**回答**：上一份工作离职是因为工作性质属于天天出差，然后偏离了本职工作，每天都要求去各个工业园区做服务生，每次都是做与本职工作不相关的事情与自己职业规划不符。（测试阶段回答可能有差错，请谅解！）

### 3. 东莞原因
**关键词**：东莞、沿海、发展、学习  
**回答**：想在沿海发展一下，学习一下。（测试阶段回答可能有差错，请谅解！）

### 4. 退伍原因
**关键词**：退伍、部队、军人、通讯营、受伤  
**回答**：部队里面锻炼了2年就够了，我想实现我的价值。不甘心只做个通讯营战士。在里面确实苦，如果不是受伤应该还会在干3年的。（测试阶段回答可能有差错，请谅解！）

### 5. 其他问题
**回答**：请联系本人获取详细解答。

## 快速开始

### 1. 本地运行
直接双击 `index.html` 文件即可使用。

### 2. 集成到网站
```html
<!-- 在你的网站中添加 -->
<iframe 
  src="https://your-domain.com/zhang-yihang-ai-assistant/"
  width="100%" 
  height="600px"
  frameborder="0"
  style="border-radius: 15px; border: none;">
</iframe>
```

### 3. GitHub Pages部署
1. 上传到GitHub仓库
2. 启用GitHub Pages
3. 访问：`https://your-username.github.io/zhang-yihang-ai-assistant/`

## 项目结构

```
zhang-yihang-ai-assistant/
├── index.html          # 主页面
├── style.css          # 样式文件
├── script.js          # 核心逻辑
├── config.js          # 配置文件
├── README.md          # 说明文档
└── assets/            # 静态资源（可选）
```

## 自定义配置

编辑 `config.js` 文件：

```javascript
const config = {
    // 修改关键词映射
    rules: {
        keywordAnswers: {
            "新关键词": "你的新回答"
        },
        defaultAnswer: "自定义默认回答"
    },
    
    // 修改界面颜色
    ui: {
        primaryColor: "#你的颜色",
        secondaryColor: "#你的颜色"
    }
};
```

## 使用方法

### 访客操作：
1. 在输入框输入问题
2. 点击"发送"或按Enter键
3. AI助手根据关键词返回回答
4. 使用"快速提问"按钮快速提问

### 网站管理员：
1. 修改 `config.js` 中的预设回答
2. 添加新的关键词映射
3. 调整界面样式
4. 更新联系信息

## 技术栈

- **前端**：HTML5, CSS3, JavaScript (ES6+)
- **样式**：CSS Grid, Flexbox, CSS Variables
- **图标**：Font Awesome 6
- **字体**：系统字体栈

## 部署指南

### GitHub Pages
1. 创建新仓库：`zhang-yihang-ai-assistant`
2. 上传所有文件
3. Settings → Pages → 选择 `main` 分支
4. 访问：`https://username.github.io/zhang-yihang-ai-assistant/`

### 自定义域名
1. 在 `CNAME` 文件中添加域名
2. 配置DNS解析
3. 在GitHub Pages设置中启用自定义域名

### 本地服务器
```bash
# 使用Python简单服务器
python -m http.server 8000

# 或使用Node.js
npx serve .
```

## 扩展功能

### 添加新回答：
1. 在 `config.js` 的 `keywordAnswers` 中添加新关键词
2. 在 `script.js` 的 `answerMap` 中添加映射
3. 在 `index.html` 中添加快速提问按钮（可选）

### 修改界面：
1. 编辑 `style.css` 文件
2. 调整颜色、字体、间距等
3. 添加动画效果

### 添加功能：
1. 语音输入支持
2. 多语言支持
3. 回答历史记录
4. 导出对话功能

## 注意事项

1. **测试阶段**：所有回答都带有"测试阶段"提示
2. **关键词匹配**：基于简单关键词匹配，可能不完美
3. **隐私保护**：对话内容仅在浏览器中处理，不发送到服务器
4. **免责声明**：重要事宜请直接联系本人

## 许可证

MIT License - 查看 [LICENSE](LICENSE) 文件了解详情

## 联系

- GitHub: [@in9o0Bu](https://github.com/in9o0Bu)
- 项目地址: [https://github.com/in9o0Bu/zhang-yihang-ai-assistant](https://github.com/in9o0Bu/zhang-yihang-ai-assistant)

---

**让AI代表你与访客对话，提升网站互动体验！** 🚀